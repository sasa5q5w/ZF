from django.db import models

# Create your models here.
class City(models.Model):
    name = models.CharField(max_length=50,null=True,verbose_name='城市名称')
    x = models.DecimalField(max_digits=10,decimal_places=3, verbose_name='经度')
    Y = models.DecimalField(max_digits=10,decimal_places=3, verbose_name='纬度')
    tip = models.CharField(max_length=50,null=True,blank=True,verbose_name='备注')

    class Meta:
        db_table = 'City'