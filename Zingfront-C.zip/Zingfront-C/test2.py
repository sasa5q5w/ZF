def ResolveNum(num):
    # 定义一个字符串可以判断数字是否能分解
    str = ''
    # 从1开始依次尝试出符合要求的i作为分解后第一个数字
    for i in range(1,num//2+1):
        squ = (2*i-1)**2+8*num
        # 判断squ是否为完全平方数
        if int(squ**0.5)**2 == squ and squ/2 != 0:
            # 如果squ符合要求，则可求出分解后数字的个数n
            n = (1-2*i+squ**0.5)/2
            str = '%s = %s '%(num,i)
            # 循环拼接字符串，按要求输出
            for j in range(1,int(n)):
                str = str + '+ %s '%(i+j)
            print(str)
    # 如果字符串没改变，则表明数字不能分解
    if len(str) == 0:
        print('NONE')

if __name__ == '__main__':
    while True:
        num = int(input('请输入一个不大于10000的整数：'))
        if 0 <= num <= 10000:
            ResolveNum(num)
        else:
            print('请按规定输入数字！')
            continue
