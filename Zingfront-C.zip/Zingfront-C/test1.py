'''
1.首先将字符串首尾空格去掉并且全部转为小写
2.然后按空格将字符串切割成列表
3.判断字符串是否为空，为空则返回NULL
4.新建一个列表用于保存公共单词
5.遍历两个列表找出公共单词保存到公共单词列表
6.如果至少有一个公共单词，则返回第一个单词；否则返回NULL
'''


def GetSecondWord(s,t):
    # 去除字符串首尾空格并全部转为小写然后按空格切割成列表
    list_s = s.strip().lower().split(' ')
    list_t = t.strip().lower().split(' ')
    # 判断字符串是否非空
    if len(list_s) < 1:
        return 'Null'
    if len(list_t) < 1:
        return 'Null'
    list_new = []
    # 遍历两个列表找到公共单词
    for i in list_s:
        for j in list_t:
            if i == j:
                list_new.append(i)
    # 如果至少有一个相同单词，返回第一个单词
    if len(list_new) > 0:
        print('第二公共单词为：',list_new[0])
    # 如果没有相同单词，返回NULL
    else:
        print('Null')


if __name__ == '__main__':
    while True:
        s = input('请输入字符串s：')
        t = input('请输入字符串t：')
        GetSecondWord(s,t)
